package lista3.ogirinal.ldupla;

class IntNoDuplo {
	int valor;
	IntNoDuplo prox;
	IntNoDuplo ant;

	IntNoDuplo(int valorNo) {
		valor = valorNo;
		prox = ant = null;
	}
}
